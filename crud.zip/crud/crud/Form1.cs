﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace crud
{
    public partial class Form1 : Form
    {
        string connectionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|CRUD.mdf;Integrated Security=True;User Instance=True";

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO CRD VALUES (@Value1, @Value2)";
                using (SqlCommand cmd = new SqlCommand(query, cn))
                {
                    cmd.Parameters.AddWithValue("@Value1", textBox1.Text);
                    cmd.Parameters.AddWithValue("@Value2", textBox2.Text);

                    cn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
            load();
        }

        private void load()
        {
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                String sql = "SELECT * FROM CRD";
                SqlDataAdapter da = new SqlDataAdapter(sql, cn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'cRUDDataSet3.CRD' table. You can move, or remove it, as needed.
            this.cRDTableAdapter1.Fill(this.cRUDDataSet3.CRD);

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            using (SqlConnection cn = new SqlConnection(connectionString))
            {
                string sql = "DELETE FROM CRD WHERE id = @ID";
                using (SqlCommand cmd = new SqlCommand(sql, cn))
                {
                    cmd.Parameters.AddWithValue("@ID", textBox1.Text);
                    cn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
            load();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem != null)
            {

                int rt;

                DataRowView drv = (DataRowView)listBox1.SelectedItem;
                textBox1.Text = drv["ID"].ToString();
                textBox2.Text = drv["NM"].ToString(); // Replace "ColumnName3" with the appropriate column name from your database
            }
        }

        private void textBox3_KeyUp(object sender, KeyEventArgs e)
        {
                string sql = "SELECT * FROM CRD WHERE id='"+textBox3.Text+"'";
                SqlDataAdapter da = new SqlDataAdapter(sql, cn);
                da.SelectCommand.Parameters.AddWithValue("@SearchTerm", "%" + textBox3.Text + "%");
                DataTable dt = new DataTable();
                da.Fill(dt);

                listBox1.DataSource = dt;
                listBox1.DisplayMember = "ColumnName1";
        }

        private void button2_Click(object sender, EventArgs e)
        {
           DataRow[] foundRows = dt.Select($"id = {idToUpdate}"); // Assuming idToUpdate is the ID of the row to update
if (foundRows.Length > 0)
{
    // Modify the DataRow
    foundRows[0]["nm"] = newValue; // newValue is the new value for the 'nm' column

    // Update the database
    using (SqlConnection cn = new SqlConnection(connectionString))
    {
            string updateQuery = "UPDATE CRD SET nm = @NewValue WHERE id = @ID";
            using (SqlCommand cmd = new SqlCommand(updateQuery, cn))
            {
                cmd.Parameters.AddWithValue("@NewValue", newValue); // newValue is the new value for 'nm'
                cmd.Parameters.AddWithValue("@ID", idToUpdate); // idToUpdate is the ID of the row to update

                cn.Open();
                cmd.ExecuteNonQuery();
            }
        }
    }
        }

      
        }

       
    }
}
